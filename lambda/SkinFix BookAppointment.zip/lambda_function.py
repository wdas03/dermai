import json
import os
import boto3
from botocore.exceptions import ClientError

import uuid

# GLOBAL VARIABLES
DEFAULT_DYNAMO_DB = boto3.resource('dynamodb', region_name='us-east-1')
APPOINTMENTS_TABLE_NAME = 'appointments'
COUNTER_TABLE_NAME = 'appointments_counter'

def insert_dynamodb(records, db=DEFAULT_DYNAMO_DB, table=APPOINTMENTS_TABLE_NAME):
    table = db.Table(table)
    # overwrite if the same index is provided
    for record in records:
        #print(data_with_ts)
        response = table.put_item(Item=record)
    print('@insert_data: response', response)
    return response

def update_doctor_availability(doctorId, appointmentTime, db=DEFAULT_DYNAMO_DB, doctors_table='doctorsInfo'):
    table = db.Table(doctors_table)

    # Fetch doctor's current availabilities
    try:
        response = table.get_item(Key={'doctorId': doctorId})
        if 'Item' not in response:
            return False  # Doctor not found

        doctor_info = response['Item']
        availabilities = doctor_info.get('availabilities', [])

        # Remove the appointmentTime if it exists
        if appointmentTime in availabilities:
            availabilities.remove(appointmentTime)

            # Update the doctor's record
            update_response = table.update_item(
                Key={'doctorId': doctorId},
                UpdateExpression='SET availabilities = :val',
                ExpressionAttributeValues={':val': availabilities}
            )
            return True

    except ClientError as e:
        print('Error', e.response['Error']['Message'])
        return False

    return True  # Return true if appointmentTime was not in availabilities

    
def check_existing_appointment(doctorId, appointmentTime, db=DEFAULT_DYNAMO_DB, table=APPOINTMENTS_TABLE_NAME):
    table = db.Table(table)
    try:
        # Query using the secondary index
        response = table.query(
            IndexName='doctorId-appointmentTime-index',
            KeyConditionExpression=boto3.dynamodb.conditions.Key('doctorId').eq(doctorId) & 
                                    boto3.dynamodb.conditions.Key('appointmentTime').eq(appointmentTime)
        )
        # Check if any items were returned
        return 'Items' in response and len(response['Items']) > 0
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
        return False

        
def lambda_handler(event, context):
    print("EVENT --- {}".format(json.dumps(event)))
    event_json = json.dumps(event)
    
    params = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
    
    patientEmail = params['patientEmail']
    doctorId = params['doctorId']
    appointmentTime = params['appointmentTime']
    
    # Check if appointment exists
    if check_existing_appointment(doctorId, appointmentTime):
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET', 
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'Appointment already exists for this time and doctor.'})
        }
    
    # Update doctor availability
    if not update_doctor_availability(doctorId, appointmentTime):
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'Internal server error. Could not update doctor availability.'})
        }
        
    appointmentId = str(uuid.uuid4())
    
    appointmentsInfo = {}
    appointmentsInfo['appointmentId'] = appointmentId
    appointmentsInfo['patientEmail'] = patientEmail
    appointmentsInfo['doctorId'] = doctorId
    appointmentsInfo['appointmentTime'] = appointmentTime
    aptInsertion_response = insert_dynamodb([appointmentsInfo])
    print("APPOINTMENT INSERTION RESPONSE: ", aptInsertion_response)
    
    response = {}
    response['statusCode'] = 200
    response['headers'] = {'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET', 'Access-Control-Allow-Origin': "'*'"}
    response['body'] = json.dumps({'appointmentId': appointmentId, 'confirmedDate': appointmentTime})
    print("RESPONSE: ", response)
    return response