import json
import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB and S3 clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

def query_image_results(user_id, table_name):
    table = dynamodb.Table(table_name)
    try:
        response = table.query(
            IndexName='userId-index',
            KeyConditionExpression=boto3.dynamodb.conditions.Key('userId').eq(user_id)
        )
        return response.get('Items', [])
    except ClientError as e:
        print(f"An error occurred: {e.response['Error']['Message']}")
        return []

def get_presigned_url(bucket_name, object_key):
    try:
        url = s3_client.generate_presigned_url('get_object',
                                               Params={'Bucket': bucket_name, 'Key': object_key},
                                               ExpiresIn=3600)  # URL expires in 1 hour
        print(url)
        return url
    except ClientError as e:
        print(f"Error generating presigned URL: {e.response['Error']['Message']}")
        return None

def lambda_handler(event, context):
    # Parse userId from the event body
    try:
        params = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        user_id = params['userId']
    except (KeyError, TypeError, json.JSONDecodeError) as e:
        print(f"Error parsing event body: {e}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps({'message': 'Invalid request'})
        }
        
    try:
            
        # Query the imageResults from DynamoDB
        image_results = query_image_results(user_id, 'imageResults')
    
        # Generate presigned URLs for each image
        for image in image_results:
            image_key = image.get('userImageReference')
            if image_key:
                presigned_url = get_presigned_url('skinfix-patient-photos', image_key)
                if presigned_url:
                    image['presignedUrl'] = presigned_url
        
        print(json.dumps(image_results))
        # Return the result
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps(image_results)
        }
    except:
        return {
            'statusCode': 500,
            "headers": {
                "X-Requested-With": '*',
                "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                "Access-Control-Allow-Origin": '*',
                "Access-Control-Allow-Methods": 'POST,GET,OPTIONS'
            },
            'body': json.dumps('Error in prediction')
        }
