import json
import boto3

import json
import base64
import numpy as np
from PIL import Image
from io import BytesIO

import uuid

def lambda_handler(event, context):
    params = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
    
    # endpoint_name = 'tensorflow-inference-2023-12-14-10-59-22-957'
    endpoint_name = 'skinfix-ml-endpoint-v10'
    
    # Replace 'your-region' with your actual AWS region
    region = 'us-east-1'
    
    # SageMaker runtime client
    sagemaker_runtime = boto3.client('sagemaker-runtime', region_name=region)
    
    # Extract the file format from the base64 string
    base64_img = params['image']
    header, base64_data = base64_img.split(',', 1)
    file_format = header.split(';')[0].split('/')[1]  # Extracts 'png', 'jpeg', etc.

    # Generate a unique filename for the image with the correct extension
    filename = f"{uuid.uuid4()}.{file_format}"

    # Decode the base64 image data
    image_data = base64.b64decode(base64_data)

    # Create an image object using PIL
    image = Image.open(BytesIO(image_data))

    try:
        s3_client = boto3.client('s3')

        # Convert image back to bytes
        img_byte_arr = BytesIO()
        image_format = 'JPEG' if file_format.lower() == 'jpeg' else 'PNG'
        image.save(img_byte_arr, format=image_format)
        img_byte_arr = img_byte_arr.getvalue()

        # Upload the image to S3
        s3_client.put_object(Body=img_byte_arr, Bucket='skinfix-patient-photos', Key=filename)

        print(f"Image successfully uploaded to S3 with filename: {filename}")
    except Exception as e:
        print(f"Error uploading image to S3: {e}")
        
    # Convert the image to RGB (if not already in that format)
    if image.mode != 'RGB':
        image = image.convert('RGB')

    # Resize the image to (28, 28) if necessary
    image = image.resize((28, 28))

    image_np = np.array(image)
    image_np = image_np.reshape(-1, 28, 28, 3)
    image_np = image_np / 255.0

    input_data = image_np.tolist()
    
    # Convert input data to JSON format
    payload = json.dumps(input_data)
    
    try:
        # Invoke SageMaker endpoint
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType='application/json',
            Body=payload
        )
        
        # Parse the response
        result = json.loads(response['Body'].read().decode())['predictions']
        
        # Print or process the result as needed
        print("Prediction:", result)
        
        labels = {
            'Actinic keratoses': 0,
            'Basal cell carcinoma': 1,
            'Benign keratosis-like lesions': 2,
            'Dermatofibroma': 3,
            'Melanocytic nevi': 4,
            'Melanoma': 5,
            'Vascular lesions': 6
        }
        
        reversed_labels = {v: k for k, v in labels.items()}

        # Find the argmax of the first prediction
        predicted_index = np.argmax(result[0])
        
        # Map the predicted index to the corresponding condition
        predicted_condition = reversed_labels[predicted_index]
        
        # Get the probability of the predicted condition and convert it to percentage
        probability_percentage = result[0][predicted_index] * 100

        resp = {
            'condition': predicted_condition,
            'confidence': probability_percentage,
            'predictions': result[0]
        }
        
        try:
            dynamodb = boto3.resource('dynamodb')
            
            user_id = params.get('user_id', 'default_user')  # Replace 'default_user' with appropriate default or error handling
            table = dynamodb.Table('imageResults')
            item = {
                'userImageReference': filename,
                'userId': user_id,
                'reviewedBy': None,
                'isReviewed': False,
                'mlDiagnosis': json.dumps(resp),
                'isCorrectedDiagnosis': False,
                'correctedDiagnosis': None
            }
    
            # Store the data in DynamoDB
            table.put_item(Item=item)
            print(f"Data successfully stored in DynamoDB for image key: {filename}")
            
            return {
                'statusCode': 200,
                "headers": {
                    "X-Requested-With": '*',
                    "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                    "Access-Control-Allow-Origin": '*',
                    "Access-Control-Allow-Methods": 'POST,GET,OPTIONS'
                },
                'body': json.dumps(resp)
            }
        except Exception as e:
            print(f"Error storing data in DynamoDB: {e}")
            return {
                'statusCode': 500,
                "headers": {
                    "X-Requested-With": '*',
                    "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                    "Access-Control-Allow-Origin": '*',
                    "Access-Control-Allow-Methods": 'POST,GET,OPTIONS'
                },
                'body': json.dumps('Error in prediction')
            }
                
        
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            "headers": {
                "X-Requested-With": '*',
                "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                "Access-Control-Allow-Origin": '*',
                "Access-Control-Allow-Methods": 'POST,GET,OPTIONS'
            },
            'body': json.dumps('Error in prediction')
        }

