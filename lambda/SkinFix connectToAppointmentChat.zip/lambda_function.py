import json
import boto3
import os

DEFAULT_DYNAMO_DB = boto3.resource('dynamodb', region_name='us-east-1')
APPOINTMENTS_TABLE_NAME = 'appointments'
CONNECTIONS_TABLE_NAME = 'appointmentsConnections'

def lookup_appointment(key):
    db=DEFAULT_DYNAMO_DB
    table=APPOINTMENTS_TABLE_NAME
    
    table = db.Table(table)
    try:
        response = table.get_item(Key={'appointmentId': key})
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        return response['Item']

def lookup_connection(key, connectionId):
    db=DEFAULT_DYNAMO_DB
    table=CONNECTIONS_TABLE_NAME
    
    table = db.Table(table)
    try:
        response = table.get_item(Key={'appointmentId': key, 'connectionId': connectionId})
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        return response['Item']

def insert_dynamodb(records, db=DEFAULT_DYNAMO_DB, table=APPOINTMENTS_TABLE_NAME):
    table = db.Table(table)
    # overwrite if the same index is provided
    for record in records:
        #print(data_with_ts)
        response = table.put_item(Item=record)
    print('@insert_data: response', response)
    return response

def lambda_handler(event, context):
    print("EVENT --- {}".format(json.dumps(event)))
    appointmentId = event['queryStringParameters']['appointmentId']
    connectionId = event['requestContext']['connectionId']

    try:
        appointmentDoctorId = lookup_appointment(appointmentId)['doctorId']
        response = insert_dynamodb([{'appointmentId': appointmentId, 'connectionId': connectionId}], table=CONNECTIONS_TABLE_NAME)
        print("CONNECTION INSERTION RESPONSE: ", response)
        response = lookup_connection(appointmentId, connectionId)
        print("CONNECTION LOOKUP RESPONSE: ", response)
        return {}
    except:
        return {}