import json
import boto3

def lambda_handler(event, context):
    params = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
    doctor_id = params['doctor_id']
    filename = params['filename']
    correctedDiagnosis = params['corrected_diagnosis']
        
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('imageResults')
        # Update image dignosis in dynamoDB
        update_response = table.update_item(
            Key={'userImageReference': filename},
            UpdateExpression="set #correctedDiagnosis=:cd, #isCorrectedDiagnosis=:iscd, #isReviewed=:isr, #reviewedBy=:rby",
            ExpressionAttributeValues={
                ":cd": correctedDiagnosis,
                ":iscd": True,
                ":isr": True,
                ":rby": doctor_id
            },
            ExpressionAttributeNames={
                "#correctedDiagnosis": "correctedDiagnosis",
                "#isCorrectedDiagnosis": "isCorrectedDiagnosis",
                "#isReviewed": "isReviewed",
                "#reviewedBy": "reviewedBy"
            },
            ReturnValues="UPDATED_NEW"
        )
        print(f"Data successfully updated in DynamoDB for image key: {filename}")
        print(update_response)
        
        return {
            'statusCode': 200,
            "headers": {
                "X-Requested-With": '*',
                "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                "Access-Control-Allow-Origin": '*',
                "Access-Control-Allow-Methods": 'POST,GET,OPTIONS'
            },
            'body': json.dumps({'filename': filename, 'correctedDiagnosis': correctedDiagnosis, 'reviewedBy': doctor_id})
        }

    except Exception as e:
        print(f"Error storing data in DynamoDB: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps({'error': 'Internal server error'})
        }
