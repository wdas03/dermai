import json
import boto3
import hashlib
import os
from botocore.exceptions import ClientError

# GLOBAL VARIABLES
DYNAMO_DB_CLIENT = boto3.client('dynamodb')
DEFAULT_TABLE_NAME = 'patients'

def hash_password(password, salt):
    return hashlib.sha256(salt.encode() + password.encode()).hexdigest()

def lambda_handler(event, context):
    print(event)
    params = json.loads(event['body'])

    # Reference the 'patients' table
    table = boto3.resource('dynamodb').Table(DEFAULT_TABLE_NAME)

    # Extract patient info from the event
    first_name = params.get('first_name')
    last_name = params.get('last_name')
    email = params.get('email')
    password = params.get('password')

    try:
        # Check if the email already exists
        response = table.get_item(
            Key={
                'email': email
            }
        )

        if 'Item' in response:
            # Email already exists
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
                },
                'body': json.dumps({'error': 'Email already exists'})
            }

        # Generate a salt and hash the password
        salt = os.urandom(16).hex()
        hashed_password = hash_password(password, salt)

        # Insert new patient data
        table.put_item(
            Item={
                'email': email,
                'first_name': first_name,
                'last_name': last_name,
                'password': hashed_password,
                'salt': salt
            }
        )

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps({'message': 'Patient registered successfully'})
        }

    except ClientError as e:
        print(e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps({'error': 'Internal server error'})
        }
