import json
import boto3
import os

dynamodb = boto3.client('dynamodb')
DEFAULT_DYNAMO_DB = boto3.resource('dynamodb', region_name='us-east-1')
CONNECTIONS_TABLE_NAME = 'appointmentsConnections'

def lookup_connection(key):
    db=DEFAULT_DYNAMO_DB
    table=CONNECTIONS_TABLE_NAME
    
    table = db.Table(table)
    try:
        response = table.get_item(Key={'appointmentId': key})
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        return response['Item']

def lambda_handler(event, context):
    print("EVENT --- {}".format(json.dumps(event)))
    body = json.loads(event['body'])
    message = body['message']
    sender_id = body['user_id']
    connectionId = event['requestContext']['connectionId']
    
    print("ENDPOINT URL: ", "https://" + event["requestContext"]["domainName"] + "/" + event["requestContext"]["stage"])
    apigatewaymanagementapi = boto3.client(
        'apigatewaymanagementapi', 
        endpoint_url = "https://" + event["requestContext"]["domainName"] + "/" + event["requestContext"]["stage"]
    )
    
    # appointmentId = event["queryStringParameters"]['appointmentId']
    # response = lookup_connection(appointmentId)
    # print("APPOINTMENT CONNECTIONS: ", response)
    
    connections = []
    paginator = dynamodb.get_paginator('scan')
    for page in paginator.paginate(TableName=CONNECTIONS_TABLE_NAME):
        connections.extend(page['Items'])
    print("CONNECTIONS: ", connections)
    
    appointmentId = None
    foundId = False
    # search for appointmentId
    for connection in connections:
        if connection['connectionId']['S'] == connectionId:
            appointmentId = connection['appointmentId']['S']
            foundId = True
            break
    
    # broadcast to all connections with same appointmentId
    if foundId:
        for connection in connections:
            if connection['appointmentId']['S'] == appointmentId:
                apigatewaymanagementapi.post_to_connection(
                    Data=json.dumps({ "message": message, "senderID": sender_id }),
                    ConnectionId=connection['connectionId']['S']
                )
    return {}